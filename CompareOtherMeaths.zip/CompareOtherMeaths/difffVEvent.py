from skimage.metrics import peak_signal_noise_ratio, structural_similarity
from torchvision.utils import save_image
from torch import optim, floor
from torch.utils.data import DataLoader
from OptimUtil import *
from src.loss.ssimLoss import SSIM
import cv2
import torch

import torch.nn as nn
from src.model.UformerYandEvent import UformerY
import argparse, os, sys

import os
import sys




from tools import hybrid_storage, representation
import cv2
import numpy as np
from skimage.metrics import structural_similarity
from skimage.metrics import peak_signal_noise_ratio

os.environ["CUDA_VISIBLE_DEVICES"] = '6'
import os
import random
import torch
from src.datahandler.denoise_dataset2 import DenoiseDataSet
len = 200
path = '/data/ntmj/eventMain/data/frame5/'
Sid = "Dloss3"
# 765 576

Hsize = 511
Wsize = 511

folder_path = './RES/DiffV'

def showMessage(message, file):
    print(message)
    with open(file, 'a') as f:
        f.writelines(message + '\n')


def saveImg(img, path):
    img[img > 1] = 1
    img[img < 0] = 0
    cv2.imwrite(path, np.array(img[0, 0].cpu() * 255))


def calpsnr(gt, pred):
    return peak_signal_noise_ratio(gt, pred, data_range=gt.max() - gt.min())


def calssim(gt, pred):
    return structural_similarity(gt, pred, data_range=gt.max() - gt.min(), multichannel=False, gaussian_weights=True)
nums_frame = 1
nums_lowRgb = 3
total_frame = 1

class UHSEDataset:
    def __init__(self, p, nb_of_timebin=5):
        folder = p.strip('\n')
        self.storage = [hybrid_storage.HybridStorage.from_folders(event_folder=folder,
                                                                  gt_image_folder=os.path.join(folder, 'frame'),
                                                                  image_file_template="*.png",
                                                                  gt_img_timestamps_file='../ts_frame.txt',
                                                                  event_name='event.npy')]

        self.idx = []
        for k in range(1):
            self.idx += [k] * (nums_lowRgb*nums_frame)
        self.start_idx = [k*nums_lowRgb*nums_frame for k in range(1)]
        self.nb_of_time_bin = nb_of_timebin
        self.name = os.path.join(os.path.split(folder)[-1][:-1], os.path.split(folder)[-1])

    def __len__(self):

        return len-3

    def __getitem__(self, idx1):

        # sample_idx = self.idx[idx1]
        # start_idx = self.start_idx[sample_idx]
        sample_idx=0
        start_idx=0

        idx0 = idx1 - start_idx

        idx = int(idx0/nums_frame)*total_frame+idx0%nums_frame+1
        t = self.storage[sample_idx]._gtImages._timestamps[idx]

        idx_r = int(idx0/nums_frame + 1)*total_frame - 1
        idx_l = int(idx0/nums_frame)*total_frame

        left_image = self.storage[sample_idx]._gtImages._images[idx_l]
        right_image = self.storage[sample_idx]._gtImages._images[idx_r]

        t_left = self.storage[sample_idx]._gtImages._timestamps[idx_l]
        t_right = self.storage[sample_idx]._gtImages._timestamps[idx_r]

        gt_image = self.storage[sample_idx]._gtImages._images[idx]


        img =  torch.cat((left_image,gt_image,right_image),0)


        duration_left = t-t_left
        duration_right = t_right-t

        event_left = self.storage[sample_idx]._events.filter_by_timestamp(t_left, duration_left)
        event_right = self.storage[sample_idx]._events.filter_by_timestamp(t, duration_right)

        n_left = n_right = self.nb_of_time_bin*1
        event_left_forward = representation.to_count_map(event_left, n_left).clone()
        event_right_forward = representation.to_count_map(event_right, n_right).clone()

        event_right.reverse()
        event_left.reverse()
        event_left_backward = representation.to_count_map(event_left, n_left)
        event_right_backward = representation.to_count_map(event_right, n_right)


        events_forward = np.concatenate((event_left_forward, event_right_forward), axis=-1)
        events_backward = np.concatenate((event_right_backward, event_left_backward), axis=-1)



        # 进行随机裁剪为256大小
        Hr = random.randint(0, Hsize-256-1)
        Wr = random.randint(0, Wsize-256-1)

        rd1 = random.randint(0, len-2)  #取前面的
        while abs(rd1-idx)<=100:
            rd1 = random.randint(0, len - 2)  # 取前面的

        rd2 = random.randint(0, len - 2)  # 取前面的
        while abs(rd2 - idx) <= 100:
            rd2 = random.randint(0, len - 2)  # 取前面的

        image1 = self.storage[sample_idx]._gtImages._images[rd1]
        image2 = self.storage[sample_idx]._gtImages._images[rd2]
        image3 = self.storage[sample_idx]._gtImages._images[rd2]

        label =  torch.cat((image1,image2,image3),0)

        img = img[:,Hr:Hr+256,Wr:Wr+256]
        label = label[:,Hr:Hr+256,Wr:Wr+256]

        events = events_forward
        events = events[:,Hr:Hr+256,Wr:Wr+256,:]


        return events, img,label, n_left, n_right








# saved_checkpoint = torch.load('/data/tmj/FakerFlower/RES/people/peopleGray0.04justD/model/197.pth')

# module.load_state_dict(saved_checkpoint,strict=True)
# moduleB.load_state_dict(saved_checkpointB,strict=True)

# LossS = nn.L1Loss(reduction='mean').cuda()
l1loss = nn.L1Loss(reduction='mean').cuda()

# l1loss = nn.CrossEntropyLoss()
# op = optim.AdamW(module.parameters(),lr = 1e-4,weight_decay=1e-5)#定义优化器

bs = 3

ssim_loss = SSIM().cuda()

start =0
end = 200
import tqdm



if __name__ == '__main__':
    if not os.path.exists(folder_path):  # 判断是否存在文件夹如果不存在则创建为文件夹
        os.makedirs(folder_path)

    import torch
    from torch import nn, optim

    ckpt_path = ''



    input_img_channel = 1
    nb_of_time_bin = 1
    netParams = {'Ts': 1, 'tSample': nb_of_time_bin * 2}



    torch.backends.cudnn.benchmark = True
    torch.backends.cudnn.fastest = True
    # 传入 fast——ynthesisModule的结果权重
    input_size =256

    depths = [2, 2, 2, 2, 2, 2, 2, 2, 2]
    module = UformerY(img_size=input_size, embed_dim=16, depths=depths,
                                 win_size=8, mlp_ratio=4., token_projection='linear', token_mlp='leff', modulator=True,
                                 shift_flag=False).cuda()

    # with open(os.path.join(data_path, 'train.txt'), 'r') as f:
    #     lines = f.readlines()
    #
    # with open(os.path.join(data_path, 'test.txt'), 'r') as f:
    #     linesTest = f.readlines()


    if ckpt_path!='':
        module.load_state_dict(torch.load(ckpt_path))

        print('==> loading existing model:', ckpt_path)


    train_loader = UHSEDataset(path, nb_of_timebin=nb_of_time_bin)
    train_loader = torch.utils.data.DataLoader(train_loader, batch_size=1, shuffle=False, pin_memory=True, num_workers=1)

    test_loader =  UHSEDataset(path, nb_of_timebin=nb_of_time_bin)
    test_loader = torch.utils.data.DataLoader(train_loader, batch_size=1, shuffle=False, pin_memory=True, num_workers=1)

    module = module.cuda()
    loss_l1 = nn.L1Loss()


    module.train()
    start = 0
    end = 100
    import tqdm

    for epoch in range(start, end):


        if epoch % 2 ==0 and epoch >=2:

            with torch.no_grad():
                module.eval()
                psnr, ssim = [], []


                opFolder = os.path.join(folder_path,str(epoch))
                os.makedirs(opFolder, exist_ok=True)
                for i, (events, img,label, n_left, n_right )in enumerate(train_loader):
                    if i < 100:
                        events = events.cuda()
                        img = img.cuda()
                        label = label.cuda()
                        n_left = n_left.cuda()
                        n_right = n_right.cuda()

                        D,S = module(img,events ,n_left, n_right)
                        save_image(S, folder_path + '/' + str(i) + '_S.png')
                        save_image(D, folder_path + '/' + str(i) + '_D.png')
                        save_image(img[1], folder_path + '/' + str(i) + '_N.png')

        module.train()
        for i, (events,img,label, n_left, n_right )in enumerate(train_loader):
            events = events.cuda()
            img = img.cuda()
            label = label.cuda()


            n_left = n_left.cuda()
            n_right = n_right.cuda()


            preS1 = label[:, 0, :, :].unsqueeze(1)
            preS2 = label[:, 1, :, :].unsqueeze(1)

            preS3 = label[:, 2, :, :].unsqueeze(1)

            parmS = set_S_down(module)
            op1 = optim.Adam(parmS, lr=1e-4, weight_decay=1e-6)  # 定义优化器

            S, D = module(img, events, n_left, n_right)

            loss1 = l1loss(S, preS2)
            op1.zero_grad()
            loss1.backward()
            op1.step()


            parm_D = set_D(module)
            op3 = optim.Adam(parm_D, lr=1e-4, weight_decay=1e-6)  # 定义优化器
            nowS, nowD = module(img, events, n_left, n_right)

            cc = torch.reshape(nowS, (1, -1))
            max = torch.mode(cc)[0]
            pt = img[:, 1, :, :].unsqueeze(1)

            ssim_out2 = 1 - ssim_loss(pt, nowD * (nowS / max))
            op3.zero_grad()
            ssim_out2.backward(retain_graph=False)
            op3.step()


            print("epoch:   ", epoch, "loss1:", loss1.item())
        torch.save(module.state_dict(), folder_path + str(epoch) + '.pth')





