
from torchvision.utils import save_image
from torch import optim, floor
from torch.utils.data import DataLoader
from OptimUtil import *

from src.datahandler.YnetReadFlower import flower256,flowerval
from src.loss.ssimLoss import SSIM

import cv2
import torch
import numpy as np
import torch.nn as nn

from src.model.ynet import YNet

import argparse, os, sys
os.environ["CUDA_VISIBLE_DEVICES"] = '6'



module = YNet().cuda()

module.load_state_dict(torch.load('/data/tmj/FakerFlower/RES/ynet/model/8.pth'))

l1loss = nn.L1Loss(reduction='mean').cuda()

train_data = flower256()

train_loader = DataLoader(train_data,batch_size=1,shuffle=False,drop_last=True)


ssim_loss = SSIM().cuda()
ssim_loss2 = SSIM().cuda()

start = 0
end = 10

for epoch in range(start,end):
    module.train()

    for batch_id, x in enumerate(train_loader):

        noiseImg = x['real_noisy1'].cuda()

        S = x['real_noisy2'][:, 0, :, :].unsqueeze(1).cuda()
        D = x['real_noisy2'][:, 1, :, :].unsqueeze(1).cuda()


        op1 = optim.Adam(module.parameters(), lr=1e-4)  # 定义优化器

        nowS, nowD = module(noiseImg)

        loss1 = 1 - ssim_loss2(S,nowS) +  1 - ssim_loss(D,nowD)
        op1.zero_grad()
        loss1.backward()
        op1.step()


        print("epoch:   ",epoch, "loss1:",loss1.item())
        # print("epoch",epoch,"   loss2：",ssim_out2.data.item())

    if epoch % 2 ==0:

        module.eval()
        testdata = flower256()
        for i in range(80):
            x = train_data.__getitem__(i)['real_noisy1'].cuda()
            noise = x[1]
            folder_path = '/data/tmj/FakerFlower/RES/ynet/picture/' + str(epoch)
            if not os.path.exists(folder_path):  # 判断是否存在文件夹如果不存在则创建为文件夹
                os.makedirs(folder_path)

            save_image(noise, folder_path + '/' + str(i) + '_N.png')
            x = x.unsqueeze(0)
            S, D = module(x)

            save_image(S, folder_path + '/' + str(i) + '_S.png')
            save_image(D, folder_path + '/' + str(i) + '_D.png')

        print('pictureSaved')

        folder_path = '/data/tmj/FakerFlower/RES/ynet/model/'
        if not os.path.exists(folder_path):  # 判断是否存在文件夹如果不存在则创建为文件夹
            os.makedirs(folder_path)

        torch.save(module.state_dict(), folder_path + str(epoch ) + '.pth')
        print('model===saved')




