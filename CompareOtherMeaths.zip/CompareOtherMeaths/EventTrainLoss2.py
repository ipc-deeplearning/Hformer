import os
import random
import sys

from model.ModelFramePre import ModelFramePre

import torch.nn.functional as F

from OptimUtil import set_S_down, set_D
from src.loss.ssimLoss import SSIM
from src.model.UformerY import UformerY
from tools import hybrid_storage, representation
import cv2
import numpy as np
from skimage.metrics import structural_similarity
from skimage.metrics import peak_signal_noise_ratio
def calpsnr(gt, pred):
    return peak_signal_noise_ratio(gt, pred, data_range=gt.max() - gt.min())


def calssim(gt, pred):
    return structural_similarity(gt, pred, data_range=gt.max() - gt.min(), multichannel=False, gaussian_weights=True)


nums_frame = 48
nums_lowRgb = 3
total_frame = 1
imgSize = 257
length = 400

class UHSEDataset:
    def __init__(self, p, nb_of_timebin=5):
        folder = p.strip('\n')
        self.storage = [hybrid_storage.HybridStorage.from_folders(event_folder=folder,
                                                                  gt_image_folder=os.path.join(folder, 'frame'),
                                                                  image_file_template="*.png",
                                                                  gt_img_timestamps_file='../ts_frame.txt',
                                                                  event_name='event.npy')]

        self.idx = []
        for k in range(len(self.storage)):
            self.idx += [k] * (nums_lowRgb*nums_frame)
        self.start_idx = [k*nums_lowRgb*nums_frame for k in range(len(self.storage))]
        self.nb_of_time_bin = nb_of_timebin
        self.name = os.path.join(os.path.split(folder)[-1][:-1], os.path.split(folder)[-1])

    def __len__(self):
        # length = 0
        # for k in range(len(self.storage)):
        #     length += nums_lowRgb*nums_frame
        return length-1

    def __getitem__(self, idx1):
        sample_idx = 0

        # sample_idx = self.idx[idx1]
        # start_idx = self.start_idx[sample_idx]

        idx0 = idx1 +1

        idx = idx0

        t = self.storage[sample_idx]._gtImages._timestamps[idx]

        idx_r =idx0 + 1
        idx_l = idx0 - 1

        # left_image = self.storage[sample_idx]._gtImages._images[idx_l]
        # right_image = self.storage[sample_idx]._gtImages._images[idx_r]

        t_left = self.storage[sample_idx]._gtImages._timestamps[idx_l]
        t_right = self.storage[sample_idx]._gtImages._timestamps[idx_r]

        input_Img = self.storage[sample_idx]._gtImages._images[idx]

        duration_left = t-t_left
        duration_right = t_right-t

        event_left = self.storage[sample_idx]._events.filter_by_timestamp(t_left, duration_left)
        event_right = self.storage[sample_idx]._events.filter_by_timestamp(t, duration_right)

        rd1 = random.randint(0, length - 3)  # 取前面的

        gt_image = self.storage[sample_idx]._gtImages._images[rd1]



        # n_left = n_right = self.nb_of_time_bin
        # event_left_forward = representation.to_count_map(event_left, n_left).clone()
        # event_right_forward = representation.to_count_map(event_right, n_right).clone()

        left_voxel_grid = representation.to_voxel_grid(event_left, nb_of_time_bins=nb_of_time_bin)
        right_voxel_grid = representation.to_voxel_grid(event_right, nb_of_time_bins=nb_of_time_bin)

        # event_right.reverse()
        # event_left.reverse()
        # event_left_backward = representation.to_count_map(event_left, n_left)
        # event_right_backward = representation.to_count_map(event_right, n_right)
        # events_forward = np.concatenate((event_left_forward, event_right_forward), axis=-1)
        # events_backward = np.concatenate((event_right_backward, event_left_backward), axis=-1)
        #
        # events_forward = np.squeeze(events_forward, -1)
        #
        # events_backward = np.squeeze(events_backward, -1)

        input_Img = torch.cat((left_voxel_grid,input_Img,right_voxel_grid),0)


        # 进行随机裁剪为256大小
        Hr = random.randint(0, imgSize-256-1)
        Wr = random.randint(0,imgSize-256-1)
        Hr = Wr = 0

        input_Img = input_Img[:,Hr:Hr+256,Wr:Wr+256]

        gt_image = gt_image[:,Hr:Hr+256,Wr:Wr+256]


        return  gt_image,input_Img, left_voxel_grid, right_voxel_grid, idx




def showMessage(message, file):
    print(message)
    with open(file, 'a') as f:
        f.writelines(message + '\n')


def saveImg(img, path):
    img[img > 1] = 1
    img[img < 0] = 0
    cv2.imwrite(path, np.array(img[0, 0].cpu() * 255))


if __name__ == '__main__':
    folder_path = './out/time256/50frame/'
    if not os.path.exists(folder_path):  # 判断是否存在文件夹如果不存在则创建为文件夹
        os.makedirs(folder_path)

    import os
    os.environ['CUDA_VISIBLE_DEVICES'] = '7'
    import torch
    from torch import nn, optim
    split_by_scenario = False
    ckpt_path = ''
    data_path = '/data/ntmj/eventMain/data/time256/'


    input_img_channel = 1
    nb_of_time_bin = 1
    netParams = {'Ts': 1, 'tSample': nb_of_time_bin * 2}



    torch.backends.cudnn.benchmark = True
    torch.backends.cudnn.fastest = True
    # 传入 fast——ynthesisModule的结果权重
    model = UformerY(img_size=256).cuda()

    if not split_by_scenario:
        with open(os.path.join(data_path, 'train.txt'), 'r') as f:
            lines = f.readlines()

        with open(os.path.join(data_path, 'test.txt'), 'r') as f:
            linesTest = f.readlines()
    else:
        with open(os.path.join(data_path, 'test.txt'), 'r') as f:
            lines = f.readlines()



    if ckpt_path!='':
        model.load_state_dict(torch.load(ckpt_path))

        print('==> loading existing model:', ckpt_path)


    train_loader = [UHSEDataset(lines[k], nb_of_timebin=nb_of_time_bin) for k in range(len(lines))]
    train_loader = [torch.utils.data.DataLoader(train_loader[k], batch_size=1, shuffle=False, pin_memory=True, num_workers=1) for k in range(len(lines))]

    test_loader = [UHSEDataset(linesTest[k], nb_of_timebin=nb_of_time_bin) for k in range(len(linesTest))]
    test_loader = [ torch.utils.data.DataLoader(test_loader[k], batch_size=1, shuffle=False, pin_memory=True, num_workers=1) for k in range(len(linesTest))]

    model = model.cuda()
    loss_l1 = nn.L1Loss()


    start = 0
    end = 100
    import tqdm

    ssim_loss = SSIM().cuda()

    l1loss = nn.L1Loss(reduction='mean').cuda()

    op1 = optim.Adam(model.parameters(), lr=1e-4, weight_decay=1e-6)  # 定义优化器
    for epoch in range(start, end):


        if epoch % 2 ==0 and epoch >=2:

            with torch.no_grad():
                model.eval()
                psnr, ssim = [], []

                for loader in test_loader:
                    count = 0

                    opFolder = os.path.join(folder_path,str(epoch))
                    os.makedirs(opFolder, exist_ok=True)
                    for i, ( gt_image,input_Img, left_voxel_grid, right_voxel_grid, idx )in enumerate(loader):


                        gt_image = gt_image.cuda()
                        input_Img = input_Img.cuda()

                        left_voxel_grid = left_voxel_grid.cuda()
                        right_voxel_grid = right_voxel_grid.cuda()

                        parmS = set_S_down(model)
                        op1 = optim.Adam(parmS, lr=1e-4, weight_decay=1e-6)  # 定义优化器

                        nowS, nowD = model(input_Img)






                        count += 1
        model.train()
        for loader in train_loader:
            count = 0

            for i, (gt_image, input_Img, left_voxel_grid, right_voxel_grid, idx) in enumerate(loader):
                gt_image = gt_image.cuda()
                input_Img = input_Img.cuda()

                left_voxel_grid = left_voxel_grid.cuda()
                right_voxel_grid = right_voxel_grid.cuda()

                parmS = set_S_down(model)
                op1 = optim.Adam(parmS, lr=1e-4, weight_decay=1e-6)  # 定义优化器

                preS1 = gt_image[:, 0, :, :].unsqueeze(1)

                nowS, nowD = model(input_Img)
                loss1 = l1loss(nowS, preS1)
                op1.zero_grad()
                loss1.backward()
                op1.step()

                parm_D = set_D(model)
                op3 = optim.Adam(parm_D, lr=1e-4, weight_decay=1e-6)  # 定义优化器
                nowS, nowD = model(input_Img)

                cc = torch.reshape(nowS, (1, -1))
                max = torch.mode(cc)[0]
                pt = input_Img[:, 1, :, :].unsqueeze(1)

                ssim_out2 = 1 - ssim_loss(pt, nowD * (nowS / max))
                op3.zero_grad()
                ssim_out2.backward(retain_graph=False)
                op3.step()


                print("epoch:   ", epoch, "loss1:", loss1.item(), " loss3", ssim_out2.data.item())


        torch.save(model.state_dict(), folder_path + str(epoch) + '.pth')