import os


path = '/data/tmj/dataset/300_140'
dataset_path = os.path.join(path)
# dataset_path = os.path.join('/data/tmj/LGBnet/dataset/old_crop')

assert os.path.exists(dataset_path), 'There is no dataset %s' % dataset_path
i = 0
for root, _, files in os.walk(dataset_path):
    for file_name in files:
        o = os.path.join(root, file_name)
        if len(file_name.split('.')[0]) == 19:
            print(file_name)
            i = i + 1
            continue
        if len(file_name.split('.')[0])==16:
            print(file_name)
            file_name = file_name[:-5]+"000"+file_name[-5:]
            print("after",file_name)

            # file_name = file_name+".Bmp"

        if len(file_name.split('.')[0])==17:
            print(file_name)
            file_name = file_name[:-6]+"00"+file_name[-6:]

            print(file_name)

        if len(file_name.split('.')[0])==18:
            print(file_name)
            file_name = file_name[:-7]+"0"+file_name[-7:]

            print("after:",file_name)

        img_paths = os.path.join(root, file_name)


        # img_paths = o.replace("-","")
        i = i +1
        print(len(file_name.split('.')[0]))

        os.rename(o,img_paths)


print( i)
