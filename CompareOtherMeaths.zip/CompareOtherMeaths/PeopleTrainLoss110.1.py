from torchvision.utils import save_image
from torch import optim, floor
from torch.utils.data import DataLoader
from OptimUtil import *
from src.loss.ssimLoss import SSIM
import cv2
import torch
import numpy as np
import torch.nn as nn
from src.model.UformerY import UformerY
import argparse, os, sys
os.environ["CUDA_VISIBLE_DEVICES"] = '2'
import os
import random
import torch.nn.functional as F
import torch
from src.datahandler.denoise_dataset2 import DenoiseDataSet
len = 700
path = '/data/tmj/FakerFlower/data/people/output_images'
Sid = "Dloss3"
# 765 576

Hsize = 576
Wsize = 768

Savepath = './RES/people/maskNew33'

class flower256(DenoiseDataSet):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    def _scan(self):

        dataset_path = os.path.join(path)
        # dataset_path = os.path.join('/data/tmj/LGBnet/dataset/old_crop')

        assert os.path.exists(dataset_path), 'There is no dataset %s'%dataset_path

        for root, _, files in os.walk(dataset_path):
            for file_name in files:
                self.img_paths.append(os.path.join(root, file_name))


        self.img_paths.sort()


    def _load_data(self, data_idx):

        file_name1 = self.img_paths[data_idx]
        noisy_img1 = self._load_img(file_name1)

        file_name2 = self.img_paths[data_idx+1]
        noisy_img2 = self._load_img(file_name2)

        file_name3 = self.img_paths[data_idx+2]
        noisy_img3 = self._load_img(file_name3)

        # rd1 = random.randint(0,490)

        rd1 = random.randint(0, len-2)  #取前面的
        while abs(rd1-data_idx)<=100:
            rd1 = random.randint(0, len - 2)  # 取前面的

        rd2 = random.randint(0, len - 2)  # 取前面的
        while abs(rd2 - data_idx) <= 150:
            rd2 = random.randint(0, len - 2)  # 取前面的



        rd3 = random.randint(0, len - 2)  # 取前面的
        while abs(rd3 - data_idx) <= 50:
            rd3 = random.randint(0, len - 2)  # 取前面的


        file_name4 = self.img_paths[rd1]
        noisy_img4 = self._load_img(file_name4)

        file_name5 = self.img_paths[rd2]
        noisy_img5 = self._load_img(file_name5)

        file_name6 = self.img_paths[rd3]
        noisy_img6 = self._load_img(file_name6)



        noisyImage = torch.cat((noisy_img1,noisy_img2,noisy_img3),0)
        noisyImage2 = torch.cat((noisy_img4,noisy_img5,noisy_img6),0)

        # 进行随机裁剪为256大小
        Hr = random.randint(0, Hsize-256-1)
        Wr = random.randint(0, Wsize-256-1)

        noisyImage = noisyImage[:,Hr:Hr+256,Wr:Wr+256]
        noisyImage2 = noisyImage2[:,Hr:Hr+256, Wr:Wr+256]
        return {'real_noisy1': noisyImage,'real_noisy2': noisyImage2} # only noisy image dataset



class flowershow(DenoiseDataSet):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    def _scan(self):

        dataset_path = os.path.join(path)

        assert os.path.exists(dataset_path), 'There is no dataset %s'%dataset_path

        for root, _, files in os.walk(dataset_path):
            for file_name in files:
                self.img_paths.append(os.path.join(root, file_name))

        self.img_paths.sort()



    def _load_data(self, data_idx):

        file_name1 = self.img_paths[data_idx]
        noisy_img1 = self._load_img(file_name1)

        file_name2 = self.img_paths[data_idx+1]
        noisy_img2 = self._load_img(file_name2)

        file_name3 = self.img_paths[data_idx+2]
        noisy_img3 = self._load_img(file_name3)

        noisyImage = torch.cat((noisy_img1,noisy_img2,noisy_img3),0)

        # 进行随机裁剪为256大小
        # 进行随机裁剪为256大小

        Hr = 130

        Wr = 130

        noisyImage = noisyImage[:,Hr:Hr+256,Wr:Wr+256]

        # clean_img = self._load_img(file_name)

        # return {'clean': clean_img, 'real_noisy': noisy_img} # paired dataset
        return {'real_noisy1': noisyImage} # only noisy image dataset



module = UformerY(img_size=256,out_chans=1,dd_in=3).cuda()

saved_checkpoint = torch.load('/data/tmj/FakerFlower/RES/people/maskNew2/model/70.pth')

module.load_state_dict(saved_checkpoint,strict=True)
# moduleB.load_state_dict(saved_checkpointB,strict=True)

# LossS = nn.L1Loss(reduction='mean').cuda()
l1loss = nn.L1Loss(reduction='mean').cuda()

# l1loss = nn.CrossEntropyLoss()
# op = optim.AdamW(module.parameters(),lr = 1e-4,weight_decay=1e-5)#定义优化器
train_data = flower256()
bs = 3
train_loader = DataLoader(train_data,batch_size=1,shuffle=False,drop_last=True)


ssim_loss = SSIM().cuda()

start =6
end = 100
import tqdm

for epoch in range(start,end):




    module.train()


    for batch_id, x in enumerate(train_loader):

        # 在这里执行你的代码
        noiseImg = x['real_noisy1'].cuda()
        label = x['real_noisy2'].cuda()

        pt1 = noiseImg[:,0,:,:].squeeze()
        pt = noiseImg[:,1,:,:].squeeze()

        preS1 = label[:,0,:,:].unsqueeze(1)
        preS2 = label[:,1,:,:].unsqueeze(1)

        preS3 = label[:,2,:,:].unsqueeze(1)

        #
        flow = cv2.calcOpticalFlowFarneback(pt1.cpu().detach().numpy() * 255, pt.cpu().detach().numpy() * 255, None, 0.5, 3, 15, 3, 5, 1.2, 0)
        #
        #
        pt1 = noiseImg[:,0,:,:].unsqueeze(1)
        pt = noiseImg[:,1,:,:].unsqueeze(1)
        #
        flow_magnitude = np.sqrt(flow[:, :, 0] ** 2 + flow[:, :, 1] ** 2)

        thre, mask = cv2.threshold(flow_magnitude, 1.5, 255, cv2.THRESH_BINARY)  # 二值

        mask  = torch.tensor(mask/255).cuda()
        fmask  = (1 - mask).cuda()
        # parmS = set_S_down(module)
        # op1 = optim.Adam(parmS, lr=1e-4, weight_decay=1e-6)  # 定义优化器
        nowS, nowD = module(noiseImg)
        #
        # qjS = mask*nowS   # 动态的区域
        # bjs = fmask*nowS  # 背景的区域
        # #

        # save_image(nowD, 'nowD.png')
        #
        loss1 = (1-ssim_loss(preS2,nowS))*0.2
        #
        #
        # op1.zero_grad()
        # loss1.backward()
        # op1.step()

        parm_D = set_D(module)
        op3 = optim.Adam(parm_D, lr=1e-5, weight_decay=1e-6)  # 定义优化器
        nowS, nowD = module(noiseImg)





        # cc = torch.reshape(nowS,(1,-1))
        # max = torch.mode(cc)[0]


        resDS = torch.round(nowD)

        #
        #
        #
        # nonzero_indices = torch.nonzero(resDS)
        #
        # nowS[nonzero_indices[:, 0], nonzero_indices[:, 1], nonzero_indices[:, 2], nonzero_indices[:, 3]] = pt[
        #     nonzero_indices[:, 0], nonzero_indices[:, 1], nonzero_indices[:, 2], nonzero_indices[:, 3]]

        # save_image(resDS,"Dmask.png")
        #
        reverse = 1-resDS
        #
        # save_image(reverse,"Smask.png")
        #
        # save_image(resDS*pt+reverse*nowS,"pt.png")

        # save_image(resDS*pt,"resDS_pt.png")
        #
        # save_image(pt,"pt.png")

        ssim_out2 = 1-ssim_loss(reverse*pt*fmask,nowS*fmask)


        # ssim_out2 = (1 - ssim_loss(pt,nowS)) +1-ssim_loss(resDS*pt,pt)
        # ssim_out2 =  (ssim_loss(resDS*pt,nowS)+1) +(ssim_loss(resDS*pt*fmask,pt*fmask)+1)



        op3.zero_grad()
        ssim_out2.backward(retain_graph=False)
        op3.step()
        #
        # pbar.set_description(f'Epoch {epoch + 1}/{end}')
        # pbar.set_postfix(loss1=f'{loss1.item():.6f}', loss2=f'{ssim_out2.data.item():.6f}')
        # pbar.set_postfix(loss2=f'{ssim_out2.data.item():.4f}')
        print("epoch:   ", epoch, "loss1:", loss1.item(), " loss3", ssim_out2.data.item())
        # print("epoch:   ", epoch, " loss3", ssim_out2.data.item())


    folder_path = Savepath+'/model/'
    if not os.path.exists(folder_path):  # 判断是否存在文件夹如果不存在则创建为文件夹
        os.makedirs(folder_path)



    torch.save(module.state_dict(), folder_path + str(epoch ) + '.pth')



    if epoch % 1==0 and epoch >= 0:
        module.eval()
        testdata = flowershow()
        for i in range(100):
            x = testdata.__getitem__(i)['real_noisy1'].cuda()
            noise = x[1]
            folder_path = Savepath+'/picture/' + str(epoch)
            if not os.path.exists(folder_path):  # 判断是否存在文件夹如果不存在则创建为文件夹
                os.makedirs(folder_path)

            save_image(noise, folder_path + '/' + str(i) + '_N.png')
            x = x.unsqueeze(0)
            S, D = module(x)
            resDS = torch.round(D)

            save_image(S, folder_path + '/' + str(i) + '_S.png')
            save_image(resDS, folder_path + '/' + str(i) + '_D.png')

        print('pictureSaved')
