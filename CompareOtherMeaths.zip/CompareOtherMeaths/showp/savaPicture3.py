import os
import torch
from torchvision.utils import save_image
from src.datahandler.djFlower import flowerval
from src.model.UformerY import UformerY




os.environ["CUDA_VISIBLE_DEVICES"] = '4'

module = UformerY().cuda()

module.load_state_dict(torch.load('/data/tmj/fasterMf/RES/110/4/model/39.pth'))
module.eval()
train_data = flowerval()

import time

# 使用time()测量程序运行时间
start_time = time.time()

for i in range(90):
    x = train_data.__getitem__(i)['real_noisy1'].cuda()
    noise = x[1]
    folder_path = './picture/'
    if not os.path.exists(folder_path):  # 判断是否存在文件夹如果不存在则创建为文件夹
        os.makedirs(folder_path)

    save_image(noise, folder_path + '/' + str(i) + '_N.png')
    x = x.unsqueeze(0)
    S, D = module(x)

    save_image(S, folder_path + '/' + str(i) + '_S.png')
    save_image(D, folder_path + '/' + str(i) + '_D.png')

print('model===saved')