from torchvision.utils import save_image
from torch import optim, floor
from torch.utils.data import DataLoader
from OptimUtil import *
from src.loss.ssimLoss import SSIM
import cv2
import torch
import numpy as np
import torch.nn as nn

from src.model.Uformer import Uformer
from src.model.UformerY import UformerY
import argparse, os, sys

from src.model.ynet import YNet

os.environ["CUDA_VISIBLE_DEVICES"] = '6'
import os
import random
import torch
from src.datahandler.denoise_dataset2 import DenoiseDataSet

path = '/data/40/ntmj/ntmj/eventMain/data/YnetTrain/Time7/HoloN/Img'
testpath = '/data/40/ntmj/ntmj/eventMain/data/YnetTrain/Time7/HoloN/Img'
class flower256(DenoiseDataSet):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
    def _scan(self):
        dataset_path = os.path.join(path)
        Dpath = '/data/40/ntmj/ntmj/eventMain/data/YnetTrain/Time7/HoloD/Img'

        for root, _, files in os.walk(dataset_path):
            for file_name in files:
                self.img_paths.append(os.path.join(root, file_name))

        for root, _, files in os.walk(Dpath):
            for file_name in files:
                self.Dimg.append(os.path.join(root, file_name))

        self.img_paths.sort()
        self.Dimg.sort()

    def _load_data(self, data_idx):

        file_name1 = self.img_paths[data_idx]
        noisy_img1 = self._load_img(file_name1)
        file_name2 = self.img_paths[data_idx+1]
        noisy_img2 = self._load_img(file_name2)
        file_name3 = self.img_paths[data_idx+2]
        noisy_img3 = self._load_img(file_name3)


        Dp = self.Dimg[data_idx+1]
        Di = self._load_img(Dp)


        Si = self._load_img('/data/40/ntmj/ntmj/eventMain/data/Time4/HoloN/Img')



        noisyImage = torch.cat((noisy_img1,noisy_img2,noisy_img3),0)

        # 进行随机裁剪为256大小
        Hr = random.randint(0, 512-256)
        Wr = random.randint(0,512-256)

        noisyImage = noisyImage[:,Hr:Hr+256,Wr:Wr+256]
        Di = Di[:,Hr:Hr+256, Wr:Wr+256]
        Si = Si[:,Hr:Hr+256, Wr:Wr+256]

        return {'real_noisy1': noisyImage,'D': Di,'S': Si,} # only noisy image dataset


class flowershow(DenoiseDataSet):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    def _scan(self):

        dataset_path = os.path.join(testpath)

        assert os.path.exists(dataset_path), 'There is no dataset %s'%dataset_path

        for root, _, files in os.walk(dataset_path):
            for file_name in files:
                self.img_paths.append(os.path.join(root, file_name))

        for root, _, files in os.walk("/data/40/ntmj/ntmj/eventMain/data/YnetTrain/Time7/HoloD/Img"):
            for file_name in files:
                self.Dimg.append(os.path.join(root, file_name))

        self.img_paths.sort()


    def _load_data(self, data_idx):

        file_name1 = self.img_paths[data_idx]
        noisy_img1 = self._load_img(file_name1)

        file_name2 = self.img_paths[data_idx+1]
        noisy_img2 = self._load_img(file_name2)

        file_name3 = self.img_paths[data_idx+2]
        noisy_img3 = self._load_img(file_name3)

        noisyImage = torch.cat((noisy_img1,noisy_img2,noisy_img3),0)


        Dp = self.Dimg[data_idx+1]
        D = self._load_img(Dp)


        # # 进行随机裁剪为256大小
        Hr = 30
        Wr =30
        #
        noisyImage = noisyImage[:,Hr:Hr+256,Wr:Wr+256]


        # clean_img = self._load_img(file_name)

        # return {'clean': clean_img, 'real_noisy': noisy_img} # paired dataset
        return {'real_noisy1': noisyImage,"gt":D} # only noisy image dataset

saved_checkpoint = torch.load('/data/40/ntmj/ntmj/eventMain/out/yenet/model/84best.pth')


module = YNet().cuda()

module.load_state_dict(saved_checkpoint,strict=True)


# LossS = nn.L1Loss(reduction='mean').cuda()
l1loss = nn.L1Loss(reduction='mean').cuda()

# l2loss = nn.L1Loss(reduction='mean').cuda()
l2loss = nn.L1Loss(reduction='mean').cuda()
# op = optim.AdamW(module.parameters(),lr = 1e-4,weight_decay=1e-5)#定义优化器
train_data = flower256()
bs = 3
train_loader = DataLoader(train_data,batch_size=1,shuffle=False,drop_last=True)
ssimcal = SSIM().cuda()
start = 86
end = 200
Savepath = '/data/40/ntmj/ntmj/eventMain/out/yenet'
op1 = optim.Adam(module.parameters(), lr=1e-3, weight_decay=1e-6)  # 定义优化器
bestloss = 99999
for epoch in range(start,end):
    module.train()

    for batch_id, x in enumerate(train_loader):

        noiseImg = x['real_noisy1'].cuda()

        D = x['D'].cuda()
        S = x['S'].cuda()


        nowS, nowD = module(noiseImg)
        xxx = ssimcal(nowS,S)


        loss1 =  l2loss(D,nowD)
        loss2 = l1loss(nowS, S)
        losstatal =  loss2+loss1
        op1.zero_grad()
        losstatal.backward()
        op1.step()

        print("epoch:   ",epoch, "loss1:",loss1.item())
        # print("epoch",epoch,"   loss2：",ssim_out2.data.item())

    if epoch >=0 and epoch%2==0:

        module.eval()
        testdata = flowershow()
        totaloss = 0
        for i in range(60):
            x = testdata.__getitem__(i)['real_noisy1'].cuda()

            x = x.unsqueeze(0)

            nowS, nowD = module(x)

            cc = torch.reshape(nowS, (1, -1))
            max = torch.mode(cc)[0]
            pt = x[:, 1, :, :].unsqueeze(1)
            #
            # # loss1 = l1loss(nowS, S) +  1 - l2loss(D,nowD)
            # # op1.zero_grad()
            # # loss1.backward()
            # # op1.step()
            #
            folder_path = Savepath+'/picture/' + str(epoch)
            if not os.path.exists(folder_path):  # 判断是否存在文件夹如果不存在则创建为文件夹
                os.makedirs(folder_path)
            save_image(nowD * (nowS / max), folder_path + '/' + str(i) + '_pN.png')
            save_image(nowS, folder_path + '/' + str(i) + '_S.png')
            save_image(nowD, folder_path + '/' + str(i) + '_D.png')



        folder_path = Savepath + '/model/'
        if not os.path.exists(folder_path):  # 判断是否存在文件夹如果不存在则创建为文件夹
            os.makedirs(folder_path)
        if totaloss <= bestloss:
            torch.save(module.state_dict(), folder_path + str(epoch) + 'best.pth')
            print(bestloss)
            bestloss =totaloss
        else:
            torch.save(module.state_dict(), folder_path + str(epoch) + '.pth')
            # print('pictureSaved')



    # print('model===saved')




