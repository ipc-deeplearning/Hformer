import os
from importlib import import_module
import torch
import torch.nn as nn
from src.datahandler.flower import flower

loss_class_dict = {}

def regist_loss(loss_class):
    loss_name = loss_class.__name__
    assert not loss_name in loss_class_dict, 'there is already registered loss name: %s in loss_class_dict.' % loss_name
    loss_class_dict[loss_name] = loss_class

    return loss_class

'''
## default format of loss ##

    @regist_loss
    class ():
        def __call__(self, input_data, model_output, data, model):

## example of loss: L1 loss ##

    @regist_loss
    class L1():
        def __call__(self, input_data, model_output, data, module):
            output = model_output['recon']
            return F.l1_loss(output, data['clean'])
'''

# import all python files in model folder
for module in os.listdir(os.path.dirname(__file__)):
    if module == '__init__.py' or module[-3:] != '.py':
        continue
    import_module('src.loss.{}'.format(module[:-3]))
del module


class Loss(nn.Module):
    def __init__(self, loss_string, tmp_info=[]):
        super().__init__()
        loss_string     = loss_string.replace(' ', '')

        # parse loss string
        self.loss_list = []
        for single_loss in loss_string.split('+'):
            weight, name = single_loss.split('*')
            ratio = True if 'r' in weight else False
            weight = float(weight.replace('r', ''))

            if name in loss_class_dict:
                self.loss_list.append({ 'name': name,
                                        'weight': float(weight),
                                        'func': loss_class_dict[name](),
                                        'ratio': ratio})
            else:
                raise RuntimeError('undefined loss term: {}'.format(name))
            
        # parse temporal information string
        self.tmp_info_list = []
        for name in tmp_info:
            if name in loss_class_dict:
                self.tmp_info_list.append({ 'name': name,
                                            'func': loss_class_dict[name]()})
            else:
                raise RuntimeError('undefined loss term: {}'.format(name))


    def forward(self, input_data, model_output, data, module, loss_name=None, change_name=None, ratio=1.0):

        # 修改的部分
        # forward
        # moduleA = torch.load('/data/tmj/LGBnet/output/test/checkpoint/test_025.pth')
        # modelB = torch.load('/data/tmj/LGBnet/output/modelLAN/checkpoint/modelLAN_009.pth')
        # netA = BSN().eval()
        # netB = LAN().eval()
        # netA.load_state_dict(moduleA['model_weight']['denoiser'])
        # netB.load_state_dict(modelB['model_weight']['denoiser'])
        # netA = netA.cuda()
        # netB = netB.cuda()
        #
        # with torch.no_grad():
        #     labela = netA(*input_data)
        #     lableb = netB(*input_data)
        #
        #
        # '''
        # forward all loss and return as dict format.
        # Args
        #     input_data   : input of the network (also in the data)
        #     model_output : output of the network
        #     data         : entire batch of data
        #     module       : dictionary of modules (for another network forward)
        #     loss_name    : (optional) choose specific loss with name
        #     change_name  : (optional) replace name of chosen loss
        #     ratio        : (optional) percentage of learning procedure for increase weight during training
        # Return
        #     losses       : dictionary of loss
        # '''
        #
        # input_data = labela
        # data = input_data

        # 训练的任意一组的代码

        train_data = flower()

        # rd1 = random.randint(0,499)
        # rd2 = random.randint(500,980)

        rd1 = 1
        rd2 = 2

        input_data = train_data.__getitem__(rd1)['real_noisy'].cuda()

        input_data = input_data[1]
        input_data = input_data.unsqueeze(0)


        input_data2= train_data.__getitem__(rd2)['real_noisy'].cuda()
        input_data2 = input_data2[1]
        input_data2 = input_data2.unsqueeze(0)
        # input_data = torch.cat()
        input_data = input_data.unsqueeze(0)
        input_data2 = input_data2.unsqueeze(0)
        input_data = torch.cat((input_data2,input_data),0)





        loss_arg = (input_data, model_output, data, module)

        # calculate only specific loss 'loss_name' and change its name to 'change_name'
        if loss_name is not None:
            for single_loss in self.loss_list:
                if loss_name == single_loss['name']:
                    loss = single_loss['weight'] * single_loss['func'](*loss_arg)

                    if single_loss['ratio']: loss *= ratio
                    if change_name is not None:
                        return {change_name: loss}
                    return {single_loss['name']: loss}
            raise RuntimeError('there is no such loss in training losses: {}'.format(loss_name))

        # normal case: calculate all training losses at one time
        losses = {}
        for single_loss in self.loss_list:
            losses[single_loss['name']] = single_loss['weight'] * single_loss['func'](*loss_arg)
            if single_loss['ratio']: losses[single_loss['name']] *= ratio 

        # calculate temporal information
        tmp_info = {}
        for single_tmp_info in self.tmp_info_list:
            # don't need gradient
            with torch.no_grad():
                tmp_info[single_tmp_info['name']] = single_tmp_info['func'](*loss_arg)


        # alpha = generate_alpha(input_data)
        loss2 = nn.L1Loss(reduction='mean')
        # losses['self_L1'] =loss2( input_data * (1 - alpha),model_output['recon']*(1-alpha)) + loss2(alpha*lableb,alpha*model_output['recon'])






        losses['self_L1'] = loss2(input_data, model_output['recon'])

        return losses, tmp_info



def std(img, window_size=7):
    assert window_size % 2 == 1
    pad = window_size // 2

    # calculate std on the mean image of the color channels
    img = torch.mean(img, dim=1, keepdim=True)
    N, C, H, W = img.shape
    img = nn.functional.pad(img, [pad] * 4, mode='reflect')
    img = nn.functional.unfold(img, kernel_size=window_size)
    img = img.view(N, C, window_size * window_size, H, W)
    img = img - torch.mean(img, dim=2, keepdim=True)
    img = img * img
    img = torch.mean(img, dim=2, keepdim=True)
    img = torch.sqrt(img)
    img = img.squeeze(2)
    return img
def generate_alpha(input, lower=1, upper=5):
    N, C, H, W = input.shape
    ratio = input.new_ones((N, 1, H, W)) * 0.5
    input_std = std(input)



    ratio[input_std < lower] = torch.sigmoid((input_std - lower))[input_std < lower]
    ratio[input_std > upper] = torch.sigmoid((input_std - upper))[input_std > upper]
    ratio = ratio.detach()

    return ratio