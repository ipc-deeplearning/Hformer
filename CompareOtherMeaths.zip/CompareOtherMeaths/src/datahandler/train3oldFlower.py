import os
import random
import torch

from src.datahandler.denoise_dataset import DenoiseDataSet
from . import regist_dataset


len = 1990
path = '/data/tmj/LGBnet/dataset/160_105'
N = 3
M = 20


class flower256(DenoiseDataSet):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)


    def _scan(self):

        dataset_path = os.path.join(path)
        # dataset_path = os.path.join('/data/tmj/LGBnet/dataset/old_crop')

        assert os.path.exists(dataset_path), 'There is no dataset %s'%dataset_path

        for root, _, files in os.walk(dataset_path):
            for file_name in files:
                self.img_paths.append(os.path.join(root, file_name))


        self.img_paths = self.img_paths[0:len-100]
        self.img_paths.sort()


    def _load_data(self, data_idx):

        file_name1 = self.img_paths[data_idx]
        noisy_img1 = self._load_img(file_name1)

        file_name2 = self.img_paths[data_idx+1]
        noisy_img2 = self._load_img(file_name2)

        # rd1 = random.randint(0,490)

        file_name3 = self.img_paths[data_idx+2]
        noisy_img3 = self._load_img(file_name3)

        x = random.randint(1,10)
        if data_idx > N+M and x % 2 == 0:
            rd1 = random.randint(data_idx-N-M+1, data_idx-N)  #取前面的
            # rd1 = data_idx-1
        else:
            if data_idx > 8 and x % 2 == 0:
                rd1 = random.randint(data_idx - 5, data_idx - N)  # 取前面的

            elif data_idx + N+M <len-100:
                rd1 = random.randint(data_idx +N , data_idx+N+M )
            else:
                rd1 = random.randint(data_idx - N - M + 1, data_idx - N)  # 取前面的
            # rd1 = data_idx+3



        file_name4 = self.img_paths[rd1]
        noisy_img4 = self._load_img(file_name4)



        noisyImage = torch.cat((noisy_img1,noisy_img2,noisy_img3),0)
        noisyImage2 = torch.cat((noisy_img4,noisy_img4,noisy_img4),0)

        # 进行随机裁剪为256大小
        Hr = random.randint(0, 255)
        Wr = random.randint(0,255)

        noisyImage = noisyImage[:,Hr:Hr+256,Wr:Wr+256]
        noisyImage2 = noisyImage2[:,Hr:Hr+256, Wr:Wr+256]


        return {'real_noisy1': noisyImage,'real_noisy2': noisyImage2} # only noisy image dataset




class flowerval(DenoiseDataSet):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    def _scan(self):

        dataset_path = os.path.join(path)


        assert os.path.exists(dataset_path), 'There is no dataset %s'%dataset_path

        for root, _, files in os.walk(dataset_path):
            for file_name in files:
                self.img_paths.append(os.path.join(root, file_name))


        self.img_paths = self.img_paths[len-150:len-1]
        self.img_paths.sort()




    def _load_data(self, data_idx):

        file_name1 = self.img_paths[data_idx]
        noisy_img1 = self._load_img(file_name1)

        file_name2 = self.img_paths[data_idx+1]
        noisy_img2 = self._load_img(file_name2)





        noisyImage = torch.cat((noisy_img1,noisy_img2),0)

        # 进行随机裁剪为256大小
        Hr = random.randint(0, 255)
        Wr = random.randint(0,255)

        noisyImage = noisyImage[:,Hr:Hr+256,Wr:Wr+256]

        # clean_img = self._load_img(file_name)

        # return {'clean': clean_img, 'real_noisy': noisy_img} # paired dataset
        return {'real_noisy1': noisyImage} # only noisy image dataset




class flowershow(DenoiseDataSet):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    def _scan(self):

        dataset_path = os.path.join(path)


        assert os.path.exists(dataset_path), 'There is no dataset %s'%dataset_path

        for root, _, files in os.walk(dataset_path):
            for file_name in files:
                self.img_paths.append(os.path.join(root, file_name))



        self.img_paths.sort()




    def _load_data(self, data_idx):

        file_name1 = self.img_paths[data_idx]
        noisy_img1 = self._load_img(file_name1)

        file_name2 = self.img_paths[data_idx+1]
        noisy_img2 = self._load_img(file_name2)

        file_name3 = self.img_paths[data_idx+2]
        noisy_img3 = self._load_img(file_name3)

        file_name4 = self.img_paths[data_idx+3]
        noisy_img4 = self._load_img(file_name4)



        noisyImage = torch.cat((noisy_img1,noisy_img2,noisy_img3),0)
        noisyImage2 = torch.cat((noisy_img2, noisy_img3, noisy_img4), 0)

        # 进行随机裁剪为256大小
        Hr = 0
        Wr = 0

        noisyImage = noisyImage[:,Hr:Hr+256,Wr:Wr+256]
        Hr = 0
        Wr = 0
        noisyImage2 = noisyImage2[:,Hr:Hr+256,Wr:Wr+256]



        # clean_img = self._load_img(file_name)

        # return {'clean': clean_img, 'real_noisy': noisy_img} # paired dataset
        return {'real_noisy1': noisyImage,'real_noisy2': noisyImage2} # only noisy image dataset


