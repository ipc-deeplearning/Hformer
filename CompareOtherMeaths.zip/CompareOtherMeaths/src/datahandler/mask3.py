import os
import random
import re

import h5py
import torch

from src.datahandler.denoise_dataset import DenoiseDataSet



len = 1000
path = '/data/tmj/LGBnet/dataset/160_105'

class flower256(DenoiseDataSet):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)


    def _scan(self):

        dataset_path = os.path.join(path)
        # dataset_path = os.path.join('/data/tmj/LGBnet/dataset/old_crop')

        assert os.path.exists(dataset_path), 'There is no dataset %s'%dataset_path

        for root, _, files in os.walk(dataset_path):
            for file_name in files:
                self.img_paths.append(os.path.join(root, file_name))


        self.img_paths = self.img_paths[0:len]
        self.img_paths.sort()




    def _load_data(self, data_idx):

        file_name1 = self.img_paths[data_idx]
        noisy_img1 = self._load_img(file_name1)

        file_name2 = self.img_paths[data_idx+1]
        noisy_img2 = self._load_img(file_name2)

        file_name3 = self.img_paths[data_idx+2]
        noisy_img3 = self._load_img(file_name3)

        rd1 = random.randint(0, len - 150)

        if rd1 == data_idx:
            rd1 = random.randint(data_idx, len - 100)

        file_name4 = self.img_paths[rd1]
        noisy_img4 = self._load_img(file_name4)

        file_name5 = self.img_paths[rd1+1]
        noisy_img5 = self._load_img(file_name5)

        file_name6 = self.img_paths[rd1+2]
        noisy_img6 = self._load_img(file_name6)

        noisyImage = torch.cat((noisy_img1,noisy_img2,noisy_img3),0)
        noisyImage2 = torch.cat((noisy_img4,noisy_img5,noisy_img6),0)

        # 进行随机裁剪为256大小
        Hr = random.randint(0, 255)
        Wr = random.randint(0,255)

        noisyImage = noisyImage[:,Hr:Hr+256,Wr:Wr+256]
        noisyImage2 = noisyImage2[:,Hr:Hr+256, Wr:Wr+256]


        return {'real_noisy1': noisyImage,'real_noisy2': noisyImage2} # only noisy image dataset




class flowerval(DenoiseDataSet):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    def _scan(self):
        # check if the dataset exists
        #  /data/tmj/LGBnet/dataset/160_105_resize256
        dataset_path = os.path.join(path)
        # dataset_path = os.path.join('/data/tmj/LGBnet/dataset/old_crop')

        assert os.path.exists(dataset_path), 'There is no dataset %s'%dataset_path

        for root, _, files in os.walk(dataset_path):
            for file_name in files:
                self.img_paths.append(os.path.join(root, file_name))


        self.img_paths = self.img_paths[len-150:len-10]
        self.img_paths.sort()




    def _load_data(self, data_idx):

        file_name1 = self.img_paths[data_idx]
        noisy_img1 = self._load_img(file_name1)

        file_name2 = self.img_paths[data_idx+1]
        noisy_img2 = self._load_img(file_name2)

        file_name3 = self.img_paths[data_idx+2]
        noisy_img3 = self._load_img(file_name3)



        noisyImage = torch.cat((noisy_img1,noisy_img2,noisy_img3),0)

        # 进行随机裁剪为256大小
        Hr = 20
        Wr = 20

        noisyImage = noisyImage[:,Hr:Hr+256,Wr:Wr+256]



        # clean_img = self._load_img(file_name)

        # return {'clean': clean_img, 'real_noisy': noisy_img} # paired dataset
        return {'real_noisy1': noisyImage} # only noisy image dataset

