import os
import random
import torch

from src.datahandler.denoise_dataset import DenoiseDataSet
import random
len = 115

class flower256(DenoiseDataSet):
    def __init__(self, N,path,*args, **kwargs):
        self.N = N
        self.path = path
        super().__init__(*args, **kwargs)
    def _scan(self):
        dataset_path = os.path.join(self.path)

        assert os.path.exists(dataset_path), 'There is no dataset %s'%dataset_path

        for root, _, files in os.walk(dataset_path):
            for file_name in files:
                self.img_paths.append(os.path.join(root, file_name))
        self.img_paths.sort()
    def _load_data(self, data_idx):
        file_name1 = self.img_paths[data_idx]
        noisy_img1 = self._load_img(file_name1)
        file_name2 = self.img_paths[data_idx+1]
        noisy_img2 = self._load_img(file_name2)
        file_name3 = self.img_paths[data_idx+2]
        noisy_img3 = self._load_img(file_name3)
        N = self.N
        x = random.randint(1,10)
        if data_idx > N and x % 2 == 0:
            rd1 = data_idx - N
        else:
            if data_idx + N < len -3:
                rd1 = data_idx + N
            else:
                rd1 = data_idx - N
        file_name4 = self.img_paths[rd1]
        noisy_img4 = self._load_img(file_name4)

        noisyImage = torch.cat((noisy_img1,noisy_img2,noisy_img3),0)
        noisyImage2 = torch.cat((noisy_img4,noisy_img4,noisy_img4),0)

        # 进行随机裁剪为256大小
        Hr = random.randint(0, 255)
        Wr = random.randint(0,255)

        noisyImage = noisyImage[:,Hr:Hr+256,Wr:Wr+256]
        noisyImage2 = noisyImage2[:,Hr:Hr+256, Wr:Wr+256]


        return {'real_noisy1': noisyImage,'real_noisy2': noisyImage2} # only noisy image dataset




class flowerval(DenoiseDataSet):
    def __init__(self, N, path, *args, **kwargs):
        self.N = N
        self.path = path
        super().__init__(*args, **kwargs)

    def _scan(self):

        dataset_path = os.path.join(self.path)

        assert os.path.exists(dataset_path), 'There is no dataset %s'%dataset_path

        for root, _, files in os.walk(dataset_path):
            for file_name in files:
                self.img_paths.append(os.path.join(root, file_name))


        self.img_paths = self.img_paths[len - 40:len-1]
        self.img_paths.sort()
    def _load_data(self, data_idx):

        file_name1 = self.img_paths[data_idx]
        noisy_img1 = self._load_img(file_name1)

        file_name2 = self.img_paths[data_idx+1]
        noisy_img2 = self._load_img(file_name2)

        file_name3 = self.img_paths[data_idx+2]
        noisy_img3 = self._load_img(file_name3)
        noisyImage = torch.cat((noisy_img1,noisy_img2,noisy_img3),0)

        # 进行随机裁剪为256大小
        # Hr = random.randint(0, 255)
        # Wr = random.randint(0,255)

        noisyImage1 = noisyImage[:,:256,:256]
        noisyImage2 = noisyImage[:, 256:512, 256:512]
        noisyImage3 = noisyImage[:, :256, 256:512]
        noisyImage4 = noisyImage[:, 256:512,0:256]
        noisyImage = torch.cat((noisyImage1,noisyImage2,noisyImage3,noisyImage4),0)
        noisyImage = noisyImage.resize(4,3,256,256)

        return {'real_noisy1': noisyImage} # only noisy image dataset






