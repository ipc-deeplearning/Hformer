import os
import re

import h5py
import torch

from src.datahandler.denoise_dataset import DenoiseDataSet
from . import regist_dataset


# def sort_key(s):
#     # 获取图片名称
#     # y = x.split("/")[-1]
#     # x = y.split('.')[0]
#     # print((x.replace('-', '')))
#     x = s.split('/')[-1].split('.')[0]
#     x = x.replace('-', '')
#     # 匹配开头数字序号
#     # c = re.findall('\d+', tail)[0]
#     return int(x)
@regist_dataset
class flower(DenoiseDataSet):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)


    def _scan(self):
        # check if the dataset exists
        #  /data/tmj/LGBnet/dataset/160_105_resize256
        dataset_path = os.path.join('/data/tmj/LGBnet/dataset/160_105')
        # dataset_path = os.path.join('/data/tmj/LGBnet/dataset/old_crop')

        assert os.path.exists(dataset_path), 'There is no dataset %s'%dataset_path

        for root, _, files in os.walk(dataset_path):
            for file_name in files:
                self.img_paths.append(os.path.join(root, file_name))


        # self.img_paths = self.img_paths[0:200]
        self.img_paths.sort()




    def _load_data(self, data_idx):

        file_name1 = self.img_paths[data_idx]
        noisy_img1 = self._load_img(file_name1)

        file_name2 = self.img_paths[data_idx+1]
        noisy_img2 = self._load_img(file_name2)

        file_name3 = self.img_paths[data_idx+2]
        noisy_img3 = self._load_img(file_name3)

        file_name4 = self.img_paths[data_idx + 3]
        noisy_img4 = self._load_img(file_name4)

        noisyImage = torch.cat((noisy_img1,noisy_img2,noisy_img3),0)
        noisyImage2 = torch.cat((noisy_img2,noisy_img3,noisy_img4),0)




        # clean_img = self._load_img(file_name)

        # return {'clean': clean_img, 'real_noisy': noisy_img} # paired dataset
        return {'real_noisy1': noisyImage,'real_noisy2': noisyImage2} # only noisy image dataset



@regist_dataset
class flowerval(DenoiseDataSet):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    def _scan(self):
        # check if the dataset exists
        dataset_path = os.path.join('/data/tmj/flowerUformer/dataset/flower')
        # dataset_path = os.path.join('/data/tmj/LGBnet/dataset/old_crop')

        self.dataset_path = dataset_path
        assert os.path.exists(dataset_path), 'There is no dataset %s'%dataset_path

        for root, _, files in os.walk(dataset_path):
            for file_name in files:
                self.img_paths.append(os.path.join(root, file_name))

        self.img_paths = self.img_paths[0:200]



    def _load_data(self, data_idx):

        file_name1 = self.img_paths[data_idx]
        noisy_img1 = self._load_img(file_name1)

        file_name2 = self.img_paths[data_idx+1]
        noisy_img2 = self._load_img(file_name2)

        file_name3 = self.img_paths[data_idx+2]
        noisy_img3 = self._load_img(file_name3)
        noisyImage = torch.cat((noisy_img1,noisy_img2,noisy_img3),0)



        # clean_img = self._load_img(file_name)

        # return {'clean': clean_img, 'real_noisy': noisy_img} # paired dataset

        return {'real_noisy': noisyImage} # only noisy image dataset



# @regist_dataset
# class CustomPre(DenoiseDataSet):
#     def __init__(self, *args, **kwargs):
#         super().__init__(*args, **kwargs)
#
#     def _scan(self):
#         # check if the dataset exists
#         dataset_path = os.path.join('dataset/NEW50')
#         # dataset_path = os.path.join('/data/tmj/LGBnet/dataset/old_crop')
#
#         assert os.path.exists(dataset_path), 'There is no dataset %s'%dataset_path
#
#         # WRITE YOUR CODE FOR SCANNING DATA
#         # example:
#         for root, _, files in os.walk(dataset_path):
#             for file_name in files:
#                 self.img_paths.append(os.path.join(root, file_name))
#
#
#
#
#     def _load_data(self, data_idx):
#         # WRITE YOUR CODE FOR LOADING DATA FROM DATA INDEX
#         # example:
#         file_name = self.img_paths[data_idx]
#
#         noisy_img = self._load_img(file_name)
#         clean_img = self._load_img(file_name)
#
#         return {'clean': clean_img, 'real_noisy': noisy_img} # paired dataset
#         # return {'real_noisy': noisy_img} # only noisy image dataset