from PIL import Image
import os

def resize_images(input_folder, output_folder, target_size=(512, 512)):
    # 创建输出文件夹
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)

    # 遍历输入文件夹中的图像文件
    for filename in os.listdir(input_folder):
        if filename.endswith(('.png', '.jpg', '.jpeg', '.bmp')):  # 确保文件是图像文件
            input_path = os.path.join(input_folder, filename)
            output_path = os.path.join(output_folder, filename)

            # 打开图像文件
            with Image.open(input_path) as img:
                # 调整大小并保存
                resized_img = img.resize(target_size, Image.ANTIALIAS)
                resized_img.save(output_path)

if __name__ == "__main__":
    # 设置输入和输出文件夹路径
    input_folder_path = "/data/tmj/FakerFlower/data/TimingData9/CAD/Depth/"
    output_folder_path = "/data/tmj/FakerFlower/data/resize512/DReally_depath"

    # 设置目标大小
    target_size = (512, 512)

    # 调用函数进行批量处理
    resize_images(input_folder_path, output_folder_path, target_size)

