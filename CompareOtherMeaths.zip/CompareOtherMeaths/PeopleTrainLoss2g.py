from torchvision.utils import save_image
from torch import optim, floor
from torch.utils.data import DataLoader
from OptimUtil import *
from src.loss.ssimLoss import SSIM
import cv2
import torch
import numpy as np
import torch.nn as nn
from src.model.UformerY import UformerY
import argparse, os, sys
os.environ["CUDA_VISIBLE_DEVICES"] = '7'
import os
import random
import torch
from src.datahandler.denoise_dataset2 import DenoiseDataSet
len = 794
path = '/data/tmj/FakerFlower/data/people/output_images'
Sid = "Dloss3"
# 765 576

Hsize = 576
Wsize = 768

Savepath = './RES/people/peopleReverse'


class flower256(DenoiseDataSet):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    def _scan(self):

        dataset_path = os.path.join(path)
        # dataset_path = os.path.join('/data/tmj/LGBnet/dataset/old_crop')

        assert os.path.exists(dataset_path), 'There is no dataset %s'%dataset_path

        for root, _, files in os.walk(dataset_path):
            for file_name in files:
                self.img_paths.append(os.path.join(root, file_name))


        self.img_paths.sort()


    def _load_data(self, data_idx):

        file_name1 = self.img_paths[data_idx]
        noisy_img1 = self._load_img(file_name1)
        noisy_img1=1-noisy_img1

        file_name2 = self.img_paths[data_idx+1]
        noisy_img2 = self._load_img(file_name2)
        noisy_img2=1-noisy_img2

        file_name3 = self.img_paths[data_idx+2]
        noisy_img3 = self._load_img(file_name3)
        noisy_img3=1-noisy_img3

        # rd1 = random.randint(0,490)

        rd1 = random.randint(0, len-2)  #取前面的
        while abs(rd1-data_idx)<=100:
            rd1 = random.randint(0, len - 2)  # 取前面的

        file_name4 = self.img_paths[rd1]
        noisy_img4 = self._load_img(file_name4)
        noisy_img4=1-noisy_img4


        noisyImage = torch.cat((noisy_img1,noisy_img2,noisy_img3),0)
        noisyImage2 = torch.cat((noisy_img4,noisy_img4,noisy_img4),0)

        # 进行随机裁剪为256大小
        Hr = random.randint(0, Hsize-256-1)
        Wr = random.randint(0, Wsize-256-1)

        noisyImage = noisyImage[:,Hr:Hr+256,Wr:Wr+256]
        noisyImage2 = noisyImage2[:,Hr:Hr+256, Wr:Wr+256]
        return {'real_noisy1': noisyImage,'real_noisy2': noisyImage2} # only noisy image dataset



class flowershow(DenoiseDataSet):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    def _scan(self):

        dataset_path = os.path.join(path)

        assert os.path.exists(dataset_path), 'There is no dataset %s'%dataset_path

        for root, _, files in os.walk(dataset_path):
            for file_name in files:
                self.img_paths.append(os.path.join(root, file_name))

        self.img_paths.sort()



    def _load_data(self, data_idx):

        file_name1 = self.img_paths[data_idx]
        noisy_img1 = self._load_img(file_name1)

        file_name2 = self.img_paths[data_idx+1]
        noisy_img2 = self._load_img(file_name2)

        noisy_img1=1-noisy_img1

        noisy_img2 = 1 - noisy_img2



        file_name3 = self.img_paths[data_idx+2]
        noisy_img3 = self._load_img(file_name3)

        noisy_img3 = 1 - noisy_img3

        noisyImage = torch.cat((noisy_img1,noisy_img2,noisy_img3),0)

        # 进行随机裁剪为256大小
        # 进行随机裁剪为256大小

        Hr = random.randint(0, Hsize-256-1)
        Wr = random.randint(0, Wsize-256-1)

        noisyImage = noisyImage[:,Hr:Hr+256,Wr:Wr+256]

        # clean_img = self._load_img(file_name)

        # return {'clean': clean_img, 'real_noisy': noisy_img} # paired dataset
        return {'real_noisy1': noisyImage} # only noisy image dataset



module = UformerY(img_size=256,out_chans=1,dd_in=3).cuda()

saved_checkpoint = torch.load('/data/tmj/FakerFlower/RES/people/peopleReverse/model/98bestS.pth')

module.load_state_dict(saved_checkpoint,strict=True)


# LossS = nn.L1Loss(reduction='mean').cuda()
l1loss = nn.L1Loss(reduction='mean').cuda()

# l1loss = nn.CrossEntropyLoss()
# op = optim.AdamW(module.parameters(),lr = 1e-4,weight_decay=1e-5)#定义优化器
train_data = flower256()
bs = 3
train_loader = DataLoader(train_data,batch_size=1,shuffle=False,drop_last=True)


ssim_loss = SSIM().cuda()

start =100
end = 220
import tqdm


bestLossD = 9999

bestLossS = 9999

for epoch in range(start,end):
    module.train()
    pbar = tqdm.tqdm(train_loader)
    totalS = 0
    totalD = 0
    for batch_id, x in enumerate(pbar):

        # 在这里执行你的代码
        noiseImg = x['real_noisy1'].cuda()
        label = x['real_noisy2'].cuda()

        parmS = set_S_down(module)
        op1 = optim.Adam(parmS, lr=1e-4, weight_decay=1e-6)  # 定义优化器

        preS1 = label[:,0,:,:].unsqueeze(1)
        nowS, nowD = module(noiseImg)
        loss1 = l1loss(nowS,preS1)
        op1.zero_grad()
        loss1.backward()
        op1.step()

        parm_D = set_D(module)
        op3 = optim.Adam(parm_D, lr=1e-5, weight_decay=1e-6)  # 定义优化器
        nowS, nowD = module(noiseImg)

        cc = torch.reshape(nowS,(1,-1))
        max = torch.mode(cc)[0]
        pt = noiseImg[:,1,:,:].unsqueeze(1)

        ssim_out2 = 1 - ssim_loss(pt,nowD*(nowS/max))
        op3.zero_grad()
        ssim_out2.backward(retain_graph=False)
        op3.step()

        pbar.set_description(f'Epoch {epoch + 1}/{end}')
        pbar.set_postfix(loss1=f'{loss1.item():.4f}', loss2=f'{ssim_out2.data.item():.4f}')
        totalD = totalD+ssim_out2.data.item()
        totalS = totalS+loss1.item()

    folder_path = Savepath+'/model/'
    if not os.path.exists(folder_path):  # 判断是否存在文件夹如果不存在则创建为文件夹
        os.makedirs(folder_path)


    if totalD<=bestLossD:
        bestLossD = totalD

        torch.save(module.state_dict(), folder_path + str(epoch ) + 'bestD.pth')

    if totalS<=bestLossS:
        bestLossS=totalS
        torch.save(module.state_dict(), folder_path + str(epoch ) + 'bestS.pth')

    else:

        torch.save(module.state_dict(), folder_path + str(epoch) + 'bestS.pth')

    if epoch % 1==0 and epoch >= 2:
        module.eval()
        testdata = flowershow()
        for i in range(100):
            x = testdata.__getitem__(i)['real_noisy1'].cuda()
            noise = x[1]
            folder_path = Savepath+'/picture/' + str(epoch)
            if not os.path.exists(folder_path):  # 判断是否存在文件夹如果不存在则创建为文件夹
                os.makedirs(folder_path)

            save_image(noise, folder_path + '/' + str(i) + '_N.png')
            x = x.unsqueeze(0)
            S, D = module(x)

            save_image(1-S, folder_path + '/' + str(i) + '_S.png')
            save_image(1-D, folder_path + '/' + str(i) + '_D.png')



